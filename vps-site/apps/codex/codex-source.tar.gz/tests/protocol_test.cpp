#include "../src/protocol.hpp"
#include "../src/read_only_command.hpp"
#include "../src/command_summary.hpp"
#include <cassert>
#include "../src/language.hpp"
#include <iostream>
#ifndef EXPECTED_CLIENT_VERSION
#error "tools/test.sh passes the contents of VERSION as EXPECTED_CLIENT_VERSION"
#endif
using namespace assistant;
int main(){
    const std::string runtimeShell="/data/codex-ps5/runtime/tools-0195b42eb983440b31ca75b19881e9ee/sh";
    // Approval summaries describe the command, including the one wrapped by the runtime shell.
    assert(commandSummary("mv /data/notes.txt /data/archives/notes.txt")=="Moving a file");
    assert(commandSummary("mv /data/a.txt /data/b.txt")=="Renaming a file");
    assert(commandSummary(runtimeShell+" -lc 'mv /data/notes.txt /data/archives/'")=="Moving a file");
    assert(commandSummary("/bin/bash -c \"mv a b c\"")=="Moving files");
    assert(commandSummary("rm /data/a.txt")=="Deleting a file" && commandSummary("rm a b")=="Deleting files");
    assert(commandSummary("rm -rf /data/old")=="Deleting folders and their contents");
    assert(commandSummary("cp -R a b")=="Copying a folder" && commandSummary("mkdir -p /data/x")=="Creating a folder");
    assert(commandSummary("sed -i s/a/b/ f")=="Editing a file" && commandSummary("sed s/a/b/ f")=="Transforming text");
    assert(commandSummary("tar -czf out.tgz dir")=="Creating an archive" && commandSummary("tar xf a.tar")=="Extracting an archive");
    assert(commandSummary("chmod +x run.sh")=="Making a file executable" && commandSummary("chown -R me dir")=="Changing ownership of a folder and its contents");
    assert(commandSummary("cd /data && rm old.txt")=="Deleting a file" && commandSummary("cd /data")=="Changing directory");
    assert(commandSummary("env LANG=C nice -n 5 rm x")=="Deleting a file" && commandSummary("FOO=1 python3 x.py")=="Running a script");
    assert(commandSummary("find . -name '*.tmp' -delete")=="Finding and deleting files");
    assert(commandSummary("find . -exec rm {} +")=="Finding files and running a command on them");
    assert(commandSummary("sysctl kern.x=1")=="Changing system settings" && commandSummary("sysctl -n kern.ostype")=="Reading system information");
    assert(commandSummary("date")=="Reading the date" && commandSummary("date 0101120026")=="Changing the system date");
    assert(commandSummary("curl -O https://example.com/x")=="Downloading data from the network");
    assert(commandSummary("grep -r x . 2>/dev/null")=="Searching text in files" && commandSummary("ls 2>&1")=="Listing files");
    assert(commandSummary("./script.sh")=="Running a program" && commandSummary("sh install.sh")=="Running a shell script");
    // Wrapper and shell options must not be mistaken for the wrapped command.
    for(auto command:{"bash --rcfile ls -c 'rm -rf /data'","sudo -u ls rm -rf /data","sh -o ls -c ls"})
        assert(commandSummary(command)=="Running a program");
    assert(commandSummary("env -u ls rm -rf /data")=="Deleting folders and their contents");
    assert(commandSummary("sh evil.sh -c ls")=="Running a shell script");
    assert(commandSummary("env -i -u HOME rm a")=="Deleting a file" && commandSummary("sh -ec 'rm a'")=="Deleting a file");
    // Quotes in a redirection target are not modelled either.
    for(auto command:{"ls <\"a 'b\" ; rm -rf /data ; echo 'x <'","grep foo <\"in 'put\" && rm -rf /data && echo 'done <'",
                      "cat >\"a 'b\" ; rm -rf /data ; echo 'x >'"})
        assert(commandSummary(command)=="Running several commands");
    // Changing PATH means a bare name no longer names the system tool.
    for(auto command:{"PATH=/data/codex-ps5/workspace ls","PATH=.:/bin ls","env PATH=/tmp ls"})
        assert(commandSummary(command)=="Running a program");
    // Text tools that write files or run commands through their own options.
    assert(commandSummary("sort -o /data/important f")=="Writing to a file" && commandSummary("sort f")=="Transforming text");
    assert(commandSummary("sed 'w /data/out' f")=="Writing to a file" && commandSummary("sed -n 's/a/b/w out' f")=="Writing to a file");
    assert(commandSummary("sed 's/a/b/e' f")=="Running a program" && commandSummary("sed -f edit.sed f")=="Running a script");
    assert(commandSummary("sed 's/hello/world/' notes.txt")=="Transforming text" && commandSummary("sed -e 's/x/y/g' -i f")=="Editing a file");
    assert(commandSummary("awk 'BEGIN{system(\"rm -rf /data\")}'")=="Running a script");
    assert(commandSummary("awk '{print > \"/data/x\"}' f")=="Running a script");
    // Grouped and attached options (getopt) are read like separate ones.
    for(auto command:{"sed -ne 'w /data/x' -e p f","sed -e'w /data/out' f","sort -no /data/important f","sort -uo/data/important f"})
        assert(commandSummary(command)=="Writing to a file");
    assert(commandSummary("sed -nf x f")=="Running a script" && commandSummary("sed -fx f")=="Running a script");
    assert(commandSummary("sed --expression='w /data/out' f")=="Running a program" && commandSummary("sed -n p f")=="Transforming text");
    // sed scripts are read command by command: addresses and s/y operands are skipped.
    for(auto command:{"sed -n '/error/p' log","sed '/^#/d' f","sed -n '1,5p' f","sed 's/write/exec/g' f","sed 'y/abc/xyz/' f","sed '$d' f"})
        assert(commandSummary(command)=="Transforming text");
    assert(commandSummary("sed '/x/w out' f")=="Writing to a file" && commandSummary("sed '1e echo hi' f")=="Running a program");
    assert(commandSummary("sed 's/a/b/;w out' f")=="Writing to a file" && commandSummary("sed 's/a/b' f")=="Running a program");
    // sbase ends r/R names and labels at ; or }, and l/q need no separator.
    for(auto command:{"sed 'r x;w /data/important' f","sed '1{r x}w /data/important' f","sed 'l w /data/important' f","sed 'q w /data/important' f"})
        assert(commandSummary(command)=="Writing to a file");
    assert(commandSummary("sed '/[/s]/w /data/important;:]]' f")=="Running a program");
    assert(commandSummary("sed -n '$p' f")=="Transforming text" && commandSummary("sed '10q' f")=="Transforming text");
    // GNU-only forms: unknown short options, attached -i suffixes and abbreviated long options.
    assert(commandSummary("sed -l 1 '1e echo PWNED' f")=="Running a program" && commandSummary("sed -i.e1 '1e echo' f")=="Running a program");
    assert(commandSummary("sed -i.bak 's/a/b/' f")=="Editing a file");
    assert(commandSummary("sort --out=/x f")=="Writing to a file" && commandSummary("sort --compress-prog=gzip f")=="Running a program");
    // Variables that change which program or library runs.
    for(auto command:{"LD_PRELOAD=/data/x.so ls","env LD_LIBRARY_PATH=/data ls","BASH_ENV=/data/x bash -c ls","DYLD_INSERT_LIBRARIES=x ls"})
        assert(commandSummary(command)=="Running a program");
    assert(commandSummary("LANG=C ls")=="Listing files");
    // tar modes from any option form; mixed or extra modes stay generic.
    assert(commandSummary("tar --extract -f a")=="Extracting an archive" && commandSummary("tar --create --file=a dir")=="Creating an archive");
    assert(commandSummary("tar -f cx.tar -x")=="Extracting an archive" && commandSummary("tar -tvf a.tar")=="Listing an archive's contents");
    assert(commandSummary("tar -cxf a")=="Working with an archive" && commandSummary("tar --to-command=sh -xf a")=="Running a program");
    assert(commandSummary("tar -I zstd -xf a")=="Running a program");
    assert(commandSummary("tar --to-c=sh -xf a")=="Running a program" && commandSummary("tar --use-c=./x -xf a")=="Running a program");
    assert(commandSummary("tar --rs=/data/x -xf localhost:a")=="Running a program");
    assert(commandSummary("TAR_OPTIONS=--to-command=sh tar -xf a")=="Running a program");
    assert(commandSummary("env 'BASH_FUNC_ls%%=() { rm a; }' bash -c ls")=="Running a program");
    assert(commandSummary("tar -rf a b")=="Working with an archive");
    // A tool name is trusted only from system or bundled runtime directories.
    assert(commandSummary("/bin/rm a")=="Deleting a file" && commandSummary("/data/codex-ps5/runtime/tools-0195b42eb983440b31ca75b19881e9ee/ls")=="Listing files");
    for(auto command:{"/data/codex-ps5/workspace/ls","./ls","bin/ls","/data/codex-ps5/runtime/tools-x/ls","/data/codex-ps5/workspace/sh -c 'ls'"})
        assert(commandSummary(command)=="Running a program");
    // A harmless-looking first command must not hide what follows it.
    for(auto command:{"ls; rm -rf /data","ls && rm a","ls || rm a","cat a | sh","ls $(rm a)","ls `rm a`","ls &","cd /data; ls; rm a"})
        assert(commandSummary(command)=="Running several commands");
    assert(commandSummary(runtimeShell+" -lc 'ls; rm -rf /data'")=="Running several commands");
    assert(commandSummary(runtimeShell+" -lc \"ls $(rm a)\"")=="Running several commands");
    assert(commandSummary("echo hi > /data/a.txt")=="Writing to a file" && commandSummary("echo hi >>/data/a.txt")=="Writing to a file");
    assert(commandSummary("ls ';' 'a|b'")=="Listing files" && commandSummary("ls '$(x)'")=="Running several commands");
    // Escapes, comments and $'...' quoting are not modelled: a separator anywhere then counts.
    for(auto command:{"grep \"a\\\"b\" f; rm -rf /data","ls #'\nrm -rf /data","ls $'a\\'b'; rm -rf /data","cat <(rm a)"})
        assert(commandSummary(command)=="Running several commands");
    assert(commandSummary(runtimeShell+" -lc 'grep \"a\\\"b\" f; rm -rf /data'")=="Running several commands");
    // Globs, long options and combined flags never shrink what a command does.
    assert(commandSummary("rm /data/*")=="Deleting files" && commandSummary("mv *.txt d/")=="Moving files");
    assert(commandSummary("rm --recursive /data")=="Deleting folders and their contents" && commandSummary("cp -a src dst")=="Copying a folder");
    assert(commandSummary("sed -Ei s/a/b/ f")=="Editing a file" && commandSummary("sed --in-place s/a/b/ f")=="Editing a file");
    assert(commandSummary("").empty() && commandSummary("   ").empty() && commandSummary("ls 'open").empty());
    assert(fileChangeSummary(Json::parse(R"([{"path":"/data/a","kind":{"type":"add"}}])"))=="Creating a file");
    assert(fileChangeSummary(Json::parse(R"([{"path":"/data/a","kind":"delete"},{"path":"/data/b","kind":"delete"}])"))=="Deleting files");
    assert(fileChangeSummary(Json::parse(R"([{"path":"/data/a","kind":{"type":"update","move_path":null}}])"))=="Editing a file");
    assert(fileChangeSummary(Json::parse(R"([{"path":"/data/a","kind":{"type":"update","move_path":"/data/b"}}])"))=="Renaming a file");
    assert(fileChangeSummary(Json::parse(R"([{"path":"/data/a","kind":{"type":"update","move_path":"/data/old/a"}}])"))=="Moving a file");
    assert(fileChangeSummary(Json::parse(R"([{"path":"/data/a","kind":{"type":"add"}},{"path":"/data/b","diff":"x"}])"))=="Changing several files");
    assert(fileChangeSummary(Json::array()).empty() && fileChangeSummary(Json()).empty());
    for(auto command:{"df", "'df -h'", "\"df -h /data\"", "\"cat '/data/my notes.txt'\""})
        assert(readOnlyCommand(runtimeShell+" -lc "+command));
    assert(readOnlyCommand(runtimeShell+" -c 'df -h'"));
    for(auto command:{"'rm /data/a'", "'df; rm /data/a'", "'df && rm /data/a'",
                      "'df | tee /data/a'", "'df > /data/a'", "'df $(touch /data/a)'",
                      "'sh -c df'", "'df' extra", "\"cat 'unfinished\""})
        assert(!readOnlyCommand(runtimeShell+" -lc "+command));
    for(auto shell:{"sh", "/bin/sh", "/data/sh",
                    "/data/codex-ps5/runtime/tools-invalid/sh",
                    "/data/codex-ps5/runtime/tools-0195b42eb983440b31ca75b19881e9eg/sh",
                    "/data/codex-ps5/runtime/tools-0195b42eb983440b31ca75b19881e9ee/../sh"})
        assert(!readOnlyCommand(std::string(shell)+" -lc 'df -h'"));
    assert(!readOnlyCommand(runtimeShell+" -lc '"+runtimeShell+" -lc df'"));
    assert(!readOnlyCommand(runtimeShell+" -x 'df'"));
    for(auto command:{"ls -la /data", "cat '/data/my notes.txt'", "head -n 20 /data/log.txt",
                      "tail -n 10 /data/log.txt", "wc -l /data/log.txt", "grep error /data/log.txt",
                      "du -s /data", "df -h", "ps -A", "pwd", "uname -a", "whoami",
                      "readlink /data/link", "ps5-tools", "sysctl -n kern.hostname", "sysctl -b kern.proc"})
        assert(readOnlyCommand(command));
    for(auto command:{"", "rm /data/a", "mv a b", "chmod 777 a", "find /data -delete",
                      "sed -i s/a/b/ a", "sort -o a a", "tee a", "sh -c 'ls'", "env ls",
                      "/data/cat a", "./ls", "PATH=/data ls", "ls; rm a", "ls && rm a",
                      "ls | tee a", "cat a > b", "cat a 2>>b", "cat <a", "ls\nrm a",
                      "cat $(touch a)", "cat `touch a`", "ls $HOME", "ls *", "ls \\\nrm a",
                      "cat 'unfinished", "sysctl kern.hostname=x", "sysctl -w kern.hostname",
                      "sysctl", "sysctl -n", "cat /data/a\r"})
        assert(!readOnlyCommand(command));
    {
        // A failed thread/start is retried when the user sends, never automatically,
        // and the prompt is not sent until the new conversation exists.
        Protocol f;f.begin();f.ingest(R"({"id":1,"result":{}})");f.ingest(R"({"id":2,"result":{"account":{"type":"chatgpt"}}})");
        assert(f.ingest(R"({"id":3,"error":{"message":"model unavailable"}})"));
        assert(f.state.thread.empty() && f.state.threadFailed && f.state.status=="Error: model unavailable");
        auto count=f.outgoing.size();
        assert(!f.submit("Hello") && f.outgoing.size()==count+1 && !f.state.busy && f.state.messages.empty());
        auto retry=Json::parse(f.outgoing.back());assert(retry["method"]=="thread/start" && retry["id"]==4);
        assert(f.state.status=="Starting a new conversation..." && !f.state.threadFailed);
        assert(!f.submit("Hello") && f.outgoing.size()==count+1); // one attempt at a time
        assert(f.ingest(R"({"id":4,"result":{"thread":{"id":"retried"}}})"));
        assert(f.state.thread=="retried" && f.state.status=="Ready" && f.outgoing.size()==count+1);
        assert(f.submit("Hello") && f.state.busy);
    }
    {
        // A saved conversation is resumed with its history; no prompt is sent again.
        Protocol f;f.begin("saved-thread_1");assert(f.state.conversation=="saved-thread_1");
        f.ingest(R"({"id":1,"result":{}})");f.ingest(R"({"id":2,"result":{"account":{"type":"chatgpt"}}})");
        auto resume=Json::parse(f.outgoing.back());
        assert(resume["method"]=="thread/resume" && resume["id"]==3 && resume["params"]["threadId"]=="saved-thread_1");
        assert(resume["params"]["approvalPolicy"]=="untrusted" && resume["params"]["cwd"]=="/data/codex-ps5/workspace");
        // Only the latest turn is asked for, never the full history.
        assert(resume["params"]["excludeTurns"]==true && resume["params"]["initialTurnsPage"]["limit"]==1);
        assert(resume["params"]["initialTurnsPage"]["sortDirection"]=="desc" && resume["params"]["initialTurnsPage"]["itemsView"]=="summary");
        assert(!f.retryThread() && !f.submit("Hello") && f.outgoing.size()==4); // nothing while it is resumed
        assert(f.ingest(R"({"id":3,"result":{"thread":{"id":"saved-thread_1","turns":[
            {"id":"t1","items":[{"type":"userMessage","id":"u1","content":[{"type":"text","text":"Free space?"},{"type":"localImage","path":"/data/a.png"}]},
                                {"type":"commandExecution","id":"c1","command":"df -h"},
                                {"type":"agentMessage","id":"a1","text":"575 GiB left."}]},
            {"id":"t2","items":[{"type":"userMessage","id":"u2","content":[{"type":"text","text":"Thanks"}]}]}]}}})"));
        assert(f.state.thread=="saved-thread_1" && f.state.conversation=="saved-thread_1" && f.state.status=="Conversation resumed");
        assert(f.state.messages.size()==3 && f.state.messages[0].user && f.state.messages[0].text=="Free space?");
        assert(!f.state.messages[1].user && f.state.messages[1].text=="575 GiB left." && f.state.messages[2].text=="Thanks");
        assert(f.outgoing.size()==4 && !f.state.busy);
        // /new leaves it between turns only, and the next launch no longer resumes it.
        assert(f.submit("Next") && !f.newThread());
        assert(f.ingest(R"({"id":4,"result":{"turn":{"id":"turn-1"}}})"));
        assert(f.ingest(R"({"method":"turn/completed","params":{"turn":{"status":"completed"}}})"));
        auto count=f.outgoing.size();
        assert(f.newThread() && f.state.thread.empty() && f.state.conversation.empty() && f.state.messages.empty());
        auto start=Json::parse(f.outgoing.back());assert(f.outgoing.size()==count+1 && start["method"]=="thread/start");
        assert(!f.newThread() && f.outgoing.size()==count+1);
        assert(f.ingest(Json({{"id",start["id"]},{"result",{{"thread",{{"id","fresh"}}}}}}).dump()));
        assert(f.state.thread=="fresh" && f.state.conversation.empty() && f.state.status=="Ready");
        // A new thread is remembered once a prompt is sent in it, before Codex acknowledges the turn.
        assert(f.submit("Hi") && f.state.conversation=="fresh");
        // A reconnection resumes the remembered conversation instead of starting a new one.
        f.disconnect();assert(f.state.conversation=="fresh");
        f.begin(f.state.conversation);const auto init=Json::parse(f.outgoing.back())["id"].get<int>();
        f.ingest(Json({{"id",init},{"result",Json::object()}}).dump());
        f.ingest(Json({{"id",init+1},{"result",{{"account",{{"type","chatgpt"}}}}}}).dump());
        resume=Json::parse(f.outgoing.back());assert(resume["method"]=="thread/resume" && resume["params"]["threadId"]=="fresh");
    }
    {
        // The page lists the newest turns first; they are shown oldest first.
        Protocol f;f.begin("paged");f.ingest(R"({"id":1,"result":{}})");f.ingest(R"({"id":2,"result":{"account":{"type":"chatgpt"}}})");
        assert(f.ingest(R"({"id":3,"result":{"thread":{"id":"paged","turns":[]},"initialTurnsPage":{"data":[
            {"id":"t2","items":[{"type":"userMessage","id":"u2","content":[{"type":"text","text":"Second"}]},{"type":"agentMessage","id":"a2","text":"Two"}]},
            {"id":"t1","items":[{"type":"userMessage","id":"u1","content":[{"type":"text","text":"First"}]}]}],"nextCursor":null}}})"));
        assert(f.state.messages.size()==3 && f.state.messages[0].text=="First" && f.state.messages[1].text=="Second" && f.state.messages[2].text=="Two");
        assert(f.outgoing.size()==4 && Json::parse(f.outgoing.back())["method"]=="thread/resume"); // no cursor: nothing more to fetch
    }
    {
        // Older turns are fetched one per request, so no answer can exceed the line limit.
        const auto turn=[](int n){
            return Json({{"id","t"+std::to_string(n)},{"items",Json::array({
                {{"type","userMessage"},{"id","u"+std::to_string(n)},{"content",Json::array({{{"type","text"},{"text","Q"+std::to_string(n)}}})}},
                {{"type","agentMessage"},{"id","a"+std::to_string(n)},{"text","A"+std::to_string(n)}}})}});
        };
        const auto page=[&](int id,int n,Json cursor,bool initial){
            Json list={{"data",Json::array({turn(n)})},{"nextCursor",cursor}};
            return Json({{"id",id},{"result",initial?Json({{"thread",{{"id","long"}}},{"initialTurnsPage",list}}):list}}).dump();
        };
        Protocol f;f.begin("long");f.ingest(R"({"id":1,"result":{}})");f.ingest(R"({"id":2,"result":{"account":{"type":"chatgpt"}}})");
        assert(f.ingest(page(3,30,"c29",true)) && f.state.status=="Conversation resumed" && f.state.messages.size()==2);
        auto list=Json::parse(f.outgoing.back());
        assert(list["method"]=="thread/turns/list" && list["id"]==4 && list["params"]["threadId"]=="long" && list["params"]["cursor"]=="c29");
        assert(list["params"]["limit"]==1 && list["params"]["sortDirection"]=="desc" && list["params"]["itemsView"]=="summary");
        assert(f.ingest(page(4,29,"c28",false)) && f.state.messages.size()==4);
        assert(f.state.messages[0].text=="Q29" && f.state.messages[1].text=="A29" && f.state.messages[2].text=="Q30" && f.state.messages[3].text=="A30");
        // Prompts can be sent meanwhile; older turns still go before them.
        assert(f.submit("Now") && f.state.messages.back().text=="Now");
        int id=Json::parse(f.outgoing.back())["id"].get<int>();assert(id==6); // 5 is the next page
        for(int n=28,request=5;;--n){
            const auto before=f.outgoing.size();assert(f.ingest(page(request,n,"c"+std::to_string(n-1),false)));
            if(f.outgoing.size()==before)break;
            const auto next=Json::parse(f.outgoing.back());
            assert(next["method"]=="thread/turns/list" && next["params"]["cursor"]=="c"+std::to_string(n-1));
            request=next["id"].get<int>();
        }
        // At most 20 turns are restored, in order, before the new prompt.
        assert(f.state.messages.size()==41 && f.state.messages.front().text=="Q11" && f.state.messages[39].text=="A30");
        assert(f.state.messages.back().text=="Now" && f.state.status=="Codex is thinking...");
    }
    {
        // A failed page leaves the history partial without an error; /new drops pages still on their way.
        Protocol f;f.begin("long");f.ingest(R"({"id":1,"result":{}})");f.ingest(R"({"id":2,"result":{"account":{"type":"chatgpt"}}})");
        assert(f.ingest(R"({"id":3,"result":{"thread":{"id":"long"},"initialTurnsPage":{"data":[],"nextCursor":"c1"}}})"));
        assert(f.ingest(R"({"id":4,"error":{"message":"gone"}})") && f.state.status=="Conversation resumed" && f.outgoing.size()==5);
        Protocol n;n.begin("long");n.ingest(R"({"id":1,"result":{}})");n.ingest(R"({"id":2,"result":{"account":{"type":"chatgpt"}}})");
        assert(n.ingest(R"({"id":3,"result":{"thread":{"id":"long"},"initialTurnsPage":{"data":[],"nextCursor":"c1"}}})"));
        assert(n.newThread() && n.ingest(R"({"id":5,"result":{"thread":{"id":"fresh"}}})"));
        assert(n.ingest(R"({"id":4,"result":{"data":[{"id":"old","items":[{"type":"agentMessage","id":"x","text":"stale"}]}],"nextCursor":"c0"}})"));
        assert(n.state.messages.empty() && n.outgoing.size()==6 && Json::parse(n.outgoing.back())["method"]=="thread/start");
        // A resume that cut the connection is skipped: a new conversation starts, the saved one is kept.
        Protocol g;g.begin("too-big",true);assert(g.state.conversation=="too-big");
        g.ingest(R"({"id":1,"result":{}})");g.ingest(R"({"id":2,"result":{"account":{"type":"chatgpt"}}})");
        assert(Json::parse(g.outgoing.back())["method"]=="thread/start" && !g.resuming());
        assert(g.ingest(R"({"id":3,"result":{"thread":{"id":"other"}}})") && g.state.conversation=="too-big");
        assert(g.state.status=="The previous conversation could not be resumed. A new one has started.");
        // That message only belongs to the new conversation started in its place.
        Protocol k;k.begin("too-big",true);k.ingest(R"({"id":1,"result":{}})");k.ingest(R"({"id":2,"result":{"account":{"type":"chatgpt"}}})");
        assert(k.ingest(R"({"id":3,"error":{"message":"model unavailable"}})") && k.retryThread());
        assert(k.ingest(R"({"id":4,"result":{"thread":{"id":"later"}}})") && k.state.status=="Ready");
        Protocol h;h.begin("big");h.ingest(R"({"id":1,"result":{}})");h.ingest(R"({"id":2,"result":{"account":{"type":"chatgpt"}}})");
        assert(h.resuming());h.ingest(R"({"id":3,"result":{"thread":{"id":"big"}}})");assert(!h.resuming());
    }
    {
        // When a conversation cannot be resumed a new one starts, without a prompt; the saved
        // one is kept until a turn starts in the new thread, so a failed fallback does not lose it.
        Protocol f;f.begin("missing");f.ingest(R"({"id":1,"result":{}})");f.ingest(R"({"id":2,"result":{"account":{"type":"chatgpt"}}})");
        assert(f.ingest(R"({"id":3,"error":{"message":"no rollout found"}})"));
        auto start=Json::parse(f.outgoing.back());
        assert(start["method"]=="thread/start" && start["id"]==4 && start["params"]["allowProviderModelFallback"]==false);
        assert(!start["params"].contains("threadId") && f.state.conversation=="missing" && !f.state.threadFailed);
        // Codex's reason stays visible.
        assert(f.state.status=="A new conversation has started. The previous one could not be resumed: no rollout found");
        assert(f.ingest(R"({"id":4,"error":{"message":"model unavailable"}})"));
        assert(f.state.threadFailed && f.state.conversation=="missing");
        assert(f.retryThread() && Json::parse(f.outgoing.back())["method"]=="thread/start" && f.outgoing.size()==6);
        assert(f.ingest(R"({"id":5,"result":{"thread":{"id":"replacement"}}})"));
        assert(f.state.thread=="replacement" && f.state.messages.empty() && f.state.conversation=="missing" && f.outgoing.size()==6);
        assert(f.submit("Hello") && f.state.conversation=="replacement");
        // A resume answered without a usable thread ID falls back the same way.
        Protocol h;h.begin("kept");h.ingest(R"({"id":1,"result":{}})");h.ingest(R"({"id":2,"result":{"account":{"type":"chatgpt"}}})");
        assert(h.ingest(R"({"id":3,"result":{"thread":{"id":"bad id"}}})") && h.state.thread.empty() && h.state.conversation=="kept");
        assert(h.state.status=="The previous conversation could not be resumed. A new one has started.");
        assert(Json::parse(h.outgoing.back())["method"]=="thread/start");
        // A malformed saved ID, or the gameplay companion, never resumes anything.
        for(auto saved:{"../etc","bad id",""}){
            Protocol g;g.begin(saved);g.ingest(R"({"id":1,"result":{}})");g.ingest(R"({"id":2,"result":{"account":{"type":"chatgpt"}}})");
            assert(Json::parse(g.outgoing.back())["method"]=="thread/start" && g.state.conversation.empty());
        }
        Protocol game{true};game.begin("saved");game.ingest(R"({"id":1,"result":{}})");game.ingest(R"({"id":2,"result":{"account":{"type":"chatgpt"}}})");
        assert(Json::parse(game.outgoing.back())["method"]=="thread/start" && !game.newThread());
        assert(game.ingest(R"({"id":3,"result":{"thread":{"id":"g"}}})") && game.submit("Where now?"));
        assert(game.ingest(R"({"id":4,"result":{"turn":{"id":"gt"}}})") && game.state.conversation.empty());
    }
    {
        // A long turn must not push out the details of an item still waiting for approval.
        Protocol f;f.begin();
        assert(f.ingest(R"({"method":"item/started","params":{"item":{"type":"fileChange","id":"a-patch","changes":[{"path":"/data/a.txt","kind":{"type":"update"},"diff":"-old\n+new"}]}}})"));
        for(int i=0;i<100;++i){
            const auto item=Json({{"type","commandExecution"},{"id","cmd-"+std::to_string(i)},{"command","ls /data"}});
            assert(f.ingest(Json({{"method","item/started"},{"params",{{"item",item}}}}).dump()));
            assert(f.ingest(Json({{"method","item/completed"},{"params",{{"item",item}}}}).dump()));
        }
        assert(f.ingest(R"({"method":"item/fileChange/requestApproval","id":5,"params":{"itemId":"a-patch"}})"));
        const auto& a=f.state.approvals.front();
        assert(a.reviewable && a.summary=="Editing a file" && a.description.find("+new")!=std::string::npos);
        f.decide(false);
        // A completed item can no longer supply details to a request.
        assert(f.ingest(R"({"method":"item/commandExecution/requestApproval","id":6,"params":{"itemId":"cmd-3"}})"));
        assert(!f.state.approvals.front().reviewable);f.decide(true);
        assert(Json::parse(f.outgoing.back())["result"]["decision"]=="decline");
        // Each decision leaves a line in the conversation, with the effective choice.
        assert(f.state.messages.size()==2);
        assert(f.state.messages[0].decision==Decision::declined && f.state.messages[0].text=="Editing a file");
        assert(f.state.messages[1].decision==Decision::declined && f.state.messages[1].text=="A command");
    }
    language::initialize(2);
    Protocol p;p.begin();assert(p.outgoing.size()==1);
    assert(Json::parse(p.outgoing.front())["params"]["clientInfo"]["version"]==EXPECTED_CLIENT_VERSION);
    assert(p.ingest(R"({"id":1,"result":{}})"));assert(p.state.ready);
    assert(p.outgoing.size()==3);
    assert(p.ingest(R"({"id":2,"result":{"account":{"type":"chatgpt"}}})"));
    assert(p.outgoing.size()==4);
    auto threadRequest=Json::parse(p.outgoing.back())["params"];
    assert(threadRequest["model"]=="gpt-6.1-sol" && threadRequest["config"]["model_reasoning_effort"]=="low");
    assert(threadRequest["allowProviderModelFallback"]==false);
    assert(p.ingest(R"({"id":3,"result":{"thread":{"id":"test-thread"}}})"));
    p.submit("Move the file");assert(p.state.busy);
    auto turnRequest=Json::parse(p.outgoing.back())["params"];
    assert(turnRequest["model"]=="gpt-6.1-sol" && turnRequest["effort"]=="low");
    assert(p.state.messages.size()==1 && p.state.messages.front().user && p.state.messages.front().text=="Move the file");
    auto autoBefore=p.outgoing.size();
    assert(p.ingest(R"({"method":"item/commandExecution/requestApproval","id":"read-1","params":{"command":"df -h"}})"));
    assert(p.state.approvals.empty() && p.outgoing.size()==autoBefore+1);
    auto autoReply=Json::parse(p.outgoing.back());
    assert(autoReply["id"]=="read-1" && autoReply["result"]["decision"]=="accept");
    for(auto command:{"df", "'df -h'"}){
        const auto count=p.outgoing.size();
        assert(p.ingest(Json({{"method","item/commandExecution/requestApproval"},{"id","wrapped-read"},
                             {"params",{{"command",runtimeShell+" -lc "+command},
                                        {"cwd","/data/codex-ps5/workspace"}}}}).dump()));
        assert(p.state.approvals.empty() && p.outgoing.size()==count+1);
        const auto result=Json::parse(p.outgoing.back());
        assert(result["id"]=="wrapped-read" && result["result"]["decision"]=="accept");
    }
    // Each kind of request gets its own summary line next to the command's.
    const std::pair<const char*,const char*> contexts[]={
        {R"({"kind":"stdin"})","Sending input to a running command"},
        {R"({"additionalPermissions":{"fileSystem":{"write":["/data"]}}})","Checking storage space\nRequesting additional permissions"},
        {R"({"networkApprovalContext":{"host":"example.com"}})","Checking storage space\nRequesting network access"},
        {R"({"grantRoot":"/data"})","Checking storage space\nRequesting write access to a folder"}};
    for(const auto& [context,summary]:contexts){
        auto params=Json::parse(context);params["command"]=runtimeShell+" -lc 'df -h'";
        assert(p.ingest(Json({{"method","item/commandExecution/requestApproval"},{"id","context"},{"params",params}}).dump()));
        assert(p.state.approvals.size()==1 && p.state.approvals.front().summary==summary);p.decide(false);
    }
    assert(p.ingest(Json({{"method","item/commandExecution/requestApproval"},{"id","wrapped-write"},
                         {"params",{{"command",runtimeShell+" -lc 'rm /data/a'"}}}}).dump()));
    assert(p.state.approvals.size()==1);p.decide(false);
    assert(p.ingest(R"({"method":"item/started","params":{"item":{"type":"commandExecution","id":"read-parent","command":"ls /data"}}})"));
    assert(p.ingest(R"({"method":"item/commandExecution/requestApproval","id":"cached","params":{"itemId":"read-parent"}})"));
    assert(p.state.approvals.size()==1);p.decide(false);
    assert(p.ingest(R"({"method":"item/started","params":{"item":{"type":"commandExecution","id":"parent-command","command":"parent-script"}}})"));
    assert(p.ingest(R"({"method":"item/commandExecution/requestApproval","id":"approval-1","params":{"itemId":"parent-command","command":"mv a b"}})"));
    assert(p.state.approvals.front().description=="mv a b" && p.state.approvals.front().summary=="Renaming a file");
    assert(p.state.approvals.size()==1);
    auto before=p.outgoing.size();p.decide(false);assert(p.outgoing.size()==before+1);
    auto reply=Json::parse(p.outgoing.back());assert(reply["id"]=="approval-1");assert(reply["result"]["decision"]=="decline");
    assert(p.ingest(R"({"method":"item/started","params":{"item":{"type":"fileChange","id":"patch1","changes":[{"path":"/data/note.txt","kind":{"type":"update","move_path":null},"diff":"-old\n+new"}]}}})"));
    assert(p.ingest(R"({"method":"item/fileChange/requestApproval","id":77,"params":{"itemId":"patch1","reason":"edit"}})"));
    assert(p.state.approvals.front().summary=="Editing a file");
    p.decide(true);reply=Json::parse(p.outgoing.back());assert(reply["id"]==77 && reply["result"]["decision"]=="accept");
    assert(p.state.messages.back().decision==Decision::allowed && p.state.messages.back().text=="Editing a file");
    assert(p.ingest(R"({"method":"item/fileChange/requestApproval","id":78,"params":{"itemId":"unknown"}})"));
    assert(p.state.approvals.front().summary.empty());
    p.decide(true);reply=Json::parse(p.outgoing.back());assert(reply["result"]["decision"]=="decline");
    assert(p.state.messages.back().decision==Decision::declined && p.state.messages.back().text=="A file change");
    // One line per decision, after the prompt; auto-accepted reads leave none.
    assert(p.state.messages.size()==10 && p.state.messages[2].text=="Checking storage space\nRequesting additional permissions");
    assert(p.state.messages[7].decision==Decision::declined && p.state.messages[7].text=="Renaming a file");
    assert(decisionLine(p.state.messages[7])=="Refusé : Renommage d'un fichier");
    assert(decisionLine(p.state.messages[2])=="Refusé : Vérification de l'espace de stockage · Demande de permissions supplémentaires");
    assert(p.ingest(R"({"method":"item/agentMessage/delta","params":{"delta":"Created — done."}})"));assert(p.state.response=="Created — done.");
    assert(p.ingest(R"({"method":"turn/completed","params":{"turn":{"status":"failed","error":{"message":"permission denied"}}}})"));
    assert(!p.state.busy && p.state.status.find("permission denied")!=std::string::npos);
    assert(p.state.messages.size()==11 && p.state.messages.back().text=="Created — done.");
    p.submit("What about the external drive?");
    assert(p.state.messages.size()==12 && p.state.messages[10].text=="Created — done.");
    assert(p.ingest(R"({"method":"item/agentMessage/delta","params":{"itemId":"reply2","delta":"There is "}})"));
    assert(p.ingest(R"({"method":"item/agentMessage/delta","params":{"itemId":"reply2","delta":"575 GiB left."}})"));
    assert(p.state.messages.size()==13 && p.state.messages.back().text=="There is 575 GiB left.");
    assert(p.ingest(R"({"method":"item/completed","params":{"item":{"id":"reply2","type":"agentMessage","text":"There is 575.5 GiB left."}}})"));
    assert(p.state.messages.size()==13 && p.state.messages.back().text=="There is 575.5 GiB left.");
    assert(p.ingest(R"({"method":"turn/completed","params":{"turn":{"status":"completed"}}})"));
    // Quit sequence (Client::stop): decline every pending approval, then interrupt the active turn.
    p.submit("Run a long task.");
    assert(p.ingest(R"({"method":"turn/started","params":{"turn":{"id":"quit-turn"}}})"));
    assert(p.ingest(R"({"method":"item/commandExecution/requestApproval","id":"quit-1","params":{"command":"mv a b"}})"));
    assert(p.ingest(R"({"method":"item/commandExecution/requestApproval","id":"quit-2","params":{"command":"mv c d"}})"));
    assert(p.state.busy && p.state.approvals.size()==2);
    before=p.outgoing.size();
    while(!p.state.approvals.empty())p.decide(false);
    p.interrupt();
    assert(p.outgoing.size()==before+3);
    reply=Json::parse(p.outgoing[before]);assert(reply["id"]=="quit-1" && reply["result"]["decision"]=="decline");
    reply=Json::parse(p.outgoing[before+1]);assert(reply["id"]=="quit-2" && reply["result"]["decision"]=="decline");
    reply=Json::parse(p.outgoing[before+2]);
    assert(reply["method"]=="turn/interrupt" && reply["params"]["turnId"]=="quit-turn");
    // Once the turn has ended there is nothing to interrupt, so quitting queues nothing.
    assert(p.ingest(R"({"method":"turn/completed","params":{"turn":{"status":"interrupted"}}})"));
    before=p.outgoing.size();p.interrupt();assert(p.outgoing.size()==before);
    // An interrupt asked before the turn id is known is deferred until it arrives.
    p.submit("Another task.");before=p.outgoing.size();
    p.interrupt();
    assert(p.interruptPending() && p.outgoing.size()==before);
    assert(p.ingest(R"({"method":"turn/started","params":{"turn":{"id":"late-turn"}}})"));
    assert(!p.interruptPending() && p.outgoing.size()==before+1);
    reply=Json::parse(p.outgoing[before]);
    assert(reply["method"]=="turn/interrupt" && reply["params"]["turnId"]=="late-turn");
    assert(p.ingest(R"({"method":"turn/completed","params":{"turn":{"status":"interrupted"}}})"));
    // A deferred interrupt must not leak into a later turn.
    p.submit("Third task.");p.interrupt();assert(p.interruptPending());
    assert(p.ingest(R"({"method":"turn/completed","params":{"turn":{"status":"failed"}}})"));
    assert(!p.interruptPending());
    p.submit("Fourth task.");before=p.outgoing.size();
    assert(p.ingest(R"({"method":"turn/started","params":{"turn":{"id":"turn-4"}}})"));
    assert(p.outgoing.size()==before);
    assert(p.ingest(R"({"method":"turn/completed","params":{"turn":{"status":"completed"}}})"));
    assert(!p.ingest("[1,2]"));assert(!p.ingest("not json"));
    assert(!p.ingest(R"({"id":9223372036854775807,"result":{}})"));
    assert(p.state.authenticated);
    p.disconnect();assert(p.outgoing.empty() && p.state.thread.empty() && !p.state.authenticated);
    std::cout<<"Protocol: handshake, UTF-8, approvals, errors and disconnect passed\n";
}
