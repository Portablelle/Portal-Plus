#ifndef CR_WORKER_THREAD_H
#define CR_WORKER_THREAD_H
#include <pthread.h>
/* PS5 defaults to 64 KiB. Source search needs >238 KiB before TLS/JSON calls. */
#define CR_WORKER_STACK_SIZE (2u * 1024u * 1024u)
static inline int cr_worker_thread_create(pthread_t *thread, void *(*entry)(void *), void *arg) {
  pthread_attr_t attr;
  int rc = pthread_attr_init(&attr);
  if (rc != 0) return rc;
  rc = pthread_attr_setstacksize(&attr, CR_WORKER_STACK_SIZE);
  if (rc == 0) rc = pthread_create(thread, &attr, entry, arg);
  pthread_attr_destroy(&attr);
  return rc;
}
#endif
